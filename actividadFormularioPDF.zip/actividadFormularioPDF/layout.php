<?php 
function cabezera() {
 echo  ' <!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>ActividadFormulario</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
 <header>i am header</header>
' ;

} ; 
function footer(){
    
 echo '
 </body>

 <footer>i am footer</footer>

</html>';
}